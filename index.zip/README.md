# catering-mobile-app
react Native , node js , express , mongodb 

<!-- frontend admin event add get backend data structure -->
<!--  {
  "eventName": "Global Tech Summit",
  "eventPlace": "Berlin",
  "eventDate": "2024-12-25",
  "eventTime": "10:00 AM",
  "eventDescription": "A premier tech summit.",
  "eventVenue": "Grand Conference Hall",
  "eventCategory": [
    { "name": "AI and ML", "workersCount": 5 },
    { "name": "Cybersecurity", "workersCount": 8 }
  ]
} -->


<!-- profileData  -->
<!-- {
  "phoneNumber": "9988776655",
  "otp": "123456",
  "otpExpiry": "2024-12-02T12:00:00Z",
  "refreshToken": "some-refresh-token",
  "proof": {
    "aadhar": "99887655456777"
  },
  "amount": 500,
  "totalWork": 10
} -->


<!-- frontend user add data is show  -->
<!-- {
  "userId": "63f1d4aabc1234567890abcd",
  "eventId": "63f1d5ef1234567890abcdef",
  "categories": [
    { "categoryName": "Welcome Drink", "count": 10 },
    { "categoryName": "VIP Section", "count": 5 },
    { "categoryName": "Supplier", "count": 8 }
  ],
  "location": "Valluvambram Family Auditorium"
} -->